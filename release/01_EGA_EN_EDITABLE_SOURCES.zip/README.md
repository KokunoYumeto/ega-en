# EGA English editable sources

Stable language concept DOI: https://doi.org/10.5281/zenodo.21921591
Exact release DOI: https://doi.org/10.5281/zenodo.22072594
Global EGA directory DOI: https://doi.org/10.5281/zenodo.20414353

## Declared scope

This is the exact isolated source snapshot for the complete linked standalone EGA 0-IV English reader. Eight independently mutable shared-source rows were excluded from this release and are listed in ENQ46.

Inherited English is a witness. Admitted corrections are grounded in direct NUMDAM French authority, localized, reversible, and recorded in the evidence archive.

The `source/` tree is exactly enumerated by `SOURCE_MANIFEST.json`.
French and English remain independent editions; this archive contains no
bilingual, parallel, paired, side-by-side, or interleaved reader.

Source files: 127
Source bytes: 7373604
Ordinal source-tree SHA-256: `FD20159C51B06C2096EEEAB961B3C6382B2412A545886BF4315F28A01ECEF6C6`
