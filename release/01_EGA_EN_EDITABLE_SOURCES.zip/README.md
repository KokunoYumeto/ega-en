# EGA English editable sources

Stable language concept DOI: https://doi.org/10.5281/zenodo.21921591
Exact release DOI: https://doi.org/10.5281/zenodo.22061885
Global EGA directory DOI: https://doi.org/10.5281/zenodo.20414353

## Declared scope

Complete linked standalone English EGA 0-IV source tree. The cumulative direct-French recheck is complete through the terminal page of EGA III-1, and the sealed complete EGA III-2 handoff is integrated.

The inherited English text is a witness; source-grounded decisions are controlled by direct NUMDAM French authority and the evidence package.

The `source/` tree is the exact active source set enumerated by
`SOURCE_MANIFEST.json`. This archive is independent of the other language
edition and contains no bilingual, parallel, side-by-side, or interleaved reader.

Source files: 127
Source bytes: 7373516
Ordinal source-tree SHA-256: `CABE2E7468FAA80D51B9261B92C056513AE571FE5817B01358D86C2E3D5C23D1`

Build and QA histories, deterministic inverses, rejected candidates, and
unresolved items are in the separately deposited evidence/provenance archive.
