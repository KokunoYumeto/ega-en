# EGA cumulative release evidence

Flattened, privacy-projected controls for the corrected r6 cumulative release. French remains diplomatic; English is an independent source-grounded edition. No predecessor ZIP is nested; predecessor releases remain available through their public version DOIs.
