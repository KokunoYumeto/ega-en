# EGA English r8 provenance and decisions

This compact, privacy-flattened archive binds the R30 Canon queue, the D30 EGA IV-4 dispositions and exact reversible English edits, the complete r8 source manifest, and deterministic validation receipts for the cumulative reader plus the EGA III-2, IV-1, IV-3, and IV-4 standalone readers.

French authority readings remain diplomatic. The maintained English edition is independent, and each admitted correction is localized and reversible. No absolute user path, username, credential, task/thread identifier, or nested archive is included.
