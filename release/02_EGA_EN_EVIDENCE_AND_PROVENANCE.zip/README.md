# EGA English r9 provenance and decisions

This compact archive binds the complete 135-member UTF-8/LF independent English
source tree and the exact cumulative, EGA III-2, IV-1, IV-3, and IV-4 reader
binaries.  All five PDFs are inherited byte-for-byte from their validated r8
builds; r9 replaces the stale r8 editable-source archive with the co-current
source tree.

French authority remains diplomatic.  Every English correction remains
localized and reversible.  This is an independent English edition, never a
bilingual, paired, parallel, side-by-side, or interleaved reader.
